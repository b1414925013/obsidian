import tkinter as tk
from capture_logic import ScreenCaptureLogic
from ui_layout import ScreenCaptureUI


def create_app(root):
    # 创建业务逻辑实例
    logic = ScreenCaptureLogic()
    # 创建UI实例
    ui = ScreenCaptureUI(root, logic)
    return ui


if __name__ == "__main__":
    # 提示用户安装ttkbootstrap
    try:
        import ttkbootstrap
    except ImportError:
        print("请安装ttkbootstrap库: pip install ttkbootstrap")
        exit(1)
    
    # 创建并运行应用程序
    root = tk.Tk()
    app = create_app(root)
    root.mainloop()