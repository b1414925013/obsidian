import pyautogui
import time
import os
import threading
from datetime import datetime
from tkinter import messagebox

class ScreenCaptureLogic:
    def __init__(self):
        self.is_capturing = False
        self.capture_thread = None
        self.interval = 2  # 默认截图间隔
        self.save_dir = None
        self.status_callback = None
        
    def start_capture(self, status_callback):
        if not self.is_capturing:
            # 生成唯一的文件夹名，包含时间戳
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            self.save_dir = f"screenshots_{timestamp}"
            self.status_callback = status_callback
            
            # 创建保存截图的文件夹
            if not os.path.exists(self.save_dir):
                os.makedirs(self.save_dir)
                messagebox.showinfo("信息", f"创建截图保存文件夹: {os.path.abspath(self.save_dir)}")
            else:
                messagebox.showinfo("信息", f"截图将保存到: {os.path.abspath(self.save_dir)}")
            
            self.is_capturing = True
            self.status_callback("正在截图...")
            
            # 在新线程中开始截图
            self.capture_thread = threading.Thread(target=self.capture_screen_periodically)
            self.capture_thread.daemon = True
            self.capture_thread.start()
            return True
        return False
        
    def stop_capture(self):
        if self.is_capturing:
            self.is_capturing = False
            self.status_callback("已停止")
            
            # 等待线程结束
            if self.capture_thread and self.capture_thread.is_alive():
                self.capture_thread.join(timeout=1.0)
            
            messagebox.showinfo("信息", "截图已停止")
            return True
        return False
        
    def capture_screen_periodically(self):
        try:
            count = 1
            while self.is_capturing:
                # 使用与文件夹相同的时间戳，只添加递增数字
                filename = f"screenshot_{os.path.basename(self.save_dir).replace('screenshots_', '')}_{count}.png"
                filepath = os.path.join(self.save_dir, filename)
                
                # 截取屏幕并保存
                screenshot = pyautogui.screenshot()
                screenshot.save(filepath)
                
                # 更新状态
                if self.status_callback:
                    self.status_callback(f"已保存截图: {filename}")
                
                count += 1
                # 等待指定的时间间隔
                time.sleep(self.interval)
                
        except Exception as e:
            self.is_capturing = False
            if self.status_callback:
                self.status_callback("发生错误")
            messagebox.showerror("错误", f"发生错误: {str(e)}")