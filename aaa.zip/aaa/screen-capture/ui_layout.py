import tkinter as tk
from tkinter import messagebox
import ttkbootstrap as ttk
from ttkbootstrap.constants import *

class ScreenCaptureUI:
    def __init__(self, root, logic):
        self.root = root
        self.logic = logic
        self.root.title("屏幕截图工具")
        self.root.geometry("500x300")  # 增加窗口大小
        self.root.resizable(False, False)
        
        # 设置ttkbootstrap主题
        self.style = ttk.Style(theme="cosmo")  # 使用cosmo主题
        
        # 创建UI元素
        self.create_widgets()
        
    def create_widgets(self):
        # 创建主框架
        main_frame = ttk.Frame(self.root, padding="20")
        main_frame.pack(fill=BOTH, expand=YES)
        
        # 标题标签
        title_label = ttk.Label(main_frame, text="屏幕截图工具", font=("SimHei", 16, "bold"), bootstyle="primary")
        title_label.pack(pady=15)
        
        # 状态标签
        self.status_var = tk.StringVar(value="就绪")
        status_label = ttk.Label(main_frame, textvariable=self.status_var, font=("SimHei", 11), bootstyle="info")
        status_label.pack(pady=10)
        
        # 按钮框架
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(pady=20)
        
        # 开始按钮
        self.start_button = ttk.Button(button_frame, text="开始截图", command=self.on_start, bootstyle="success")
        self.start_button.pack(side=LEFT, padx=15)
        
        # 结束按钮
        self.stop_button = ttk.Button(button_frame, text="结束截图", command=self.on_stop, bootstyle="danger", state=DISABLED)
        self.stop_button.pack(side=LEFT, padx=15)
        
        # 退出按钮
        self.exit_button = ttk.Button(main_frame, text="退出", command=self.root.quit, bootstyle="warning")
        self.exit_button.pack(pady=20)
        
        # 确保所有按钮可见
        self.root.update_idletasks()
        self.root.minsize(self.root.winfo_width(), self.root.winfo_height())
        
    def on_start(self):
        if self.logic.start_capture(self.update_status):
            self.start_button.config(state=DISABLED)
            self.stop_button.config(state=NORMAL)
        
    def on_stop(self):
        if self.logic.stop_capture():
            self.start_button.config(state=NORMAL)
            self.stop_button.config(state=DISABLED)
        
    def update_status(self, status):
        self.status_var.set(status)