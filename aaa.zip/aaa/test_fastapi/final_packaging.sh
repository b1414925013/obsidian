#!/bin/bash

# Final packaging script for FastAPI CRUD application (Linux version)

# Create a new virtual environment
python3 -m venv .venv
source .venv/bin/activate

# Install dependencies
.venv/bin/python3 -m pip install --upgrade pip
.venv/bin/python3 -m pip install -r requirements.txt

# Delete old build files
if [ -d "build" ]; then
    rm -rf build
fi
if [ -d "dist" ]; then
    rm -rf dist
fi
if [ -d "__pycache__" ]; then
    rm -rf __pycache__
fi

# Package with PyInstaller directly
pyinstaller --clean --onefile --name=main --add-data "static:static" --add-data "templates:templates" main.py

# Show completion message
if [ $? -eq 0 ]; then
    echo "Packaging completed successfully!"
    echo "The executable is located in the 'dist' directory."
    echo "You can run the application by executing './dist/main'."
else
    echo "Packaging failed with error code $?"
fi
read -p "Press Enter to continue..." 

# Deactivate the virtual environment
deactivate

# Run the application (optional)
# ./dist/main