from fastapi import FastAPI, Request, Depends, HTTPException, status
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse
from typing import Optional
import uvicorn

# 导入路由、模型和数据库配置
from routes import router as api_router
from models import Base
from database import engine, get_db, Session

# 初始化FastAPI应用
app = FastAPI(title="FastAPI CRUD App", description="A simple CRUD application with FastAPI and SQLAlchemy")

# 配置模板和静态文件
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")

# 创建数据库表
Base.metadata.create_all(bind=engine)

# 首页路由
@app.get("/")
async def read_root(request: Request, db: Session = Depends(get_db)):
    return templates.TemplateResponse("index.html", {"request": request})

# 包含API路由
app.include_router(api_router, prefix="/api")

# 运行应用
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)