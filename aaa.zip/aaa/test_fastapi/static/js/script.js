document.addEventListener('DOMContentLoaded', function() {
    // 加载所有项目
    loadItems();

    // 添加新项目表单提交事件
    document.getElementById('addItemForm').addEventListener('submit', function(e) {
        e.preventDefault();
        addItem();
    });

    // 保存编辑按钮点击事件
    document.getElementById('saveEditBtn').addEventListener('click', function() {
        saveEditItem();
    });
});

// 加载所有项目
function loadItems() {
    fetch('/api/items')
        .then(response => response.json())
        .then(data => {
            const tableBody = document.getElementById('itemsTableBody');
            tableBody.innerHTML = '';

            data.forEach(item => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.id}</td>
                    <td>${item.name}</td>
                    <td>${item.description || '-'}</td>
                    <td>$${item.price.toFixed(2)}</td>
                    <td>${new Date(item.created_at).toLocaleString()}</td>
                    <td>
                        <button class="btn btn-sm btn-primary me-2" onclick="editItem(${item.id})">Edit</button>
                        <button class="btn btn-sm btn-danger" onclick="deleteItem(${item.id})">Delete</button>
                    </td>
                `;
                tableBody.appendChild(row);
            });
        })
        .catch(error => console.error('Error loading items:', error));
}

// 添加新项目
function addItem() {
    const name = document.getElementById('name').value;
    const description = document.getElementById('description').value;
    const price = document.getElementById('price').value;

    fetch('/api/items', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, description, price })
    })
        .then(response => response.json())
        .then(data => {
            // 清空表单
            document.getElementById('addItemForm').reset();
            // 重新加载项目列表
            loadItems();
        })
        .catch(error => console.error('Error adding item:', error));
}

// 编辑项目
function editItem(id) {
    fetch(`/api/items/${id}`)
        .then(response => response.json())
        .then(item => {
            document.getElementById('editItemId').value = item.id;
            document.getElementById('editName').value = item.name;
            document.getElementById('editDescription').value = item.description || '';
            document.getElementById('editPrice').value = item.price;

            // 显示模态框
            const editModal = new bootstrap.Modal(document.getElementById('editItemModal'));
            editModal.show();
        })
        .catch(error => console.error('Error loading item for edit:', error));
}

// 保存编辑的项目
function saveEditItem() {
    const id = document.getElementById('editItemId').value;
    const name = document.getElementById('editName').value;
    const description = document.getElementById('editDescription').value;
    const price = document.getElementById('editPrice').value;

    fetch(`/api/items/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, description, price })
    })
        .then(response => response.json())
        .then(data => {
            // 关闭模态框
            const editModal = bootstrap.Modal.getInstance(document.getElementById('editItemModal'));
            editModal.hide();
            // 重新加载项目列表
            loadItems();
        })
        .catch(error => console.error('Error updating item:', error));
}

// 删除项目
function deleteItem(id) {
    if (confirm('Are you sure you want to delete this item?')) {
        fetch(`/api/items/${id}`, {
            method: 'DELETE'
        })
            .then(() => {
                // 重新加载项目列表
                loadItems();
            })
            .catch(error => console.error('Error deleting item:', error));
    }
}