# FastAPI CRUD 应用打包与部署指南

## 项目概述
这是一个使用FastAPI构建的简单CRUD应用程序，包含基本的物品管理功能。本指南提供了如何将该应用打包为可执行文件并在Windows和Linux系统上部署的步骤。

## 打包说明

### 前提条件
- Python 3.7+ 已安装
- 已安装所需依赖：`fastapi`, `uvicorn`, `sqlalchemy`, `pyinstaller`, `jinja2`

## Windows 部署方法

### 使用最终打包脚本
1. 确保所有项目文件（`main.py`, `models.py`, `routes.py`, `database.py`, `templates/`, `static/`）都在同一目录下。

2. 运行最终打包脚本：
   ```
   final_packaging.bat
   ```

3. 脚本将自动执行以下步骤：
   - 创建并激活虚拟环境
   - 安装/更新必要的依赖
   - 删除旧的构建文件
   - 使用PyInstaller直接打包应用
   - 将可执行文件输出到`dist`目录

### 手动打包（可选）
如果你想手动控制打包过程，可以执行以下步骤：

1. 创建并激活虚拟环境：
   ```
   python -m venv .venv
   .venv\Scripts\activate.bat
   ```

2. 安装依赖：
   ```
   pip install --upgrade pip
   pip install -r requirements.txt
   ```

3. 删除旧的构建文件：
   ```
   if exist build rmdir /s /q build
   if exist dist rmdir /s /q dist
   if exist __pycache__ rmdir /s /q __pycache__
   ```

4. 直接打包：
   ```
   pyinstaller --clean --onefile --name=main --add-data "static;static" --add-data "templates;templates" main.py
   ```

### 运行应用
打包完成后，你可以在`dist`目录下找到`main.exe`文件。双击该文件或在命令行中执行：
```
cd dist
main.exe
```

## Linux 部署方法

### 使用最终打包脚本
1. 确保所有项目文件（`main.py`, `models.py`, `routes.py`, `database.py`, `templates/`, `static/`）都在同一目录下。

2. 为脚本添加执行权限：
   ```
   chmod +x final_packaging.sh
   ```

3. 运行最终打包脚本：
   ```
   ./final_packaging.sh
   ```

4. 脚本将自动执行以下步骤：
   - 创建并激活虚拟环境
   - 安装/更新必要的依赖
   - 删除旧的构建文件
   - 使用PyInstaller直接打包应用
   - 将可执行文件输出到`dist`目录

### 手动打包（可选）
如果你想手动控制打包过程，可以执行以下步骤：

1. 创建并激活虚拟环境：
   ```
   python3 -m venv .venv
   source .venv/bin/activate
   ```

2. 安装依赖：
   ```
   pip install --upgrade pip
   pip install -r requirements.txt
   ```

3. 删除旧的构建文件：
   ```
   rm -rf build dist __pycache__
   ```

4. 直接打包：
   ```
   pyinstaller --clean --onefile --name=main --add-data "static:static" --add-data "templates:templates" main.py
   ```

### 运行应用
打包完成后，你可以在`dist`目录下找到`main`可执行文件。在命令行中执行：
```
cd dist
./main
```

## 访问应用
应用启动后，在浏览器中访问 `http://localhost:8000` 即可使用。

## 故障排除
- 如果遇到模块缺失错误，确保所有必要的依赖都已安装。
- 如果静态文件或模板无法加载，检查打包命令中的`--add-data`参数配置是否正确。
- 对于其他问题，尝试使用`--debug`模式打包，以获取更详细的错误信息。

## 注意事项
- Windows系统使用的可执行文件为`main.exe`，Linux系统使用的可执行文件为`main`。
- 首次运行可能需要一些时间，请耐心等待。
- 应用使用SQLite数据库，数据存储在`items.db`文件中。
- 确保在对应系统上使用正确的脚本和命令。