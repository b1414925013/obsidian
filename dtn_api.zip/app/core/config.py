from pydantic_settings import BaseSettings  # ✅ Pydantic 2.x 推荐
from pydantic import Field


class Settings(BaseSettings):
    APP_NAME: str = Field(default="My FastAPI Project")
    DATABASE_URL: str = Field(default="sqlite:///./test.db")

    SECRET_KEY: str = Field(default="mysecretkey")
    ALGORITHM: str = Field(default="HS256")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(default=30)

    WHITE_LIST_IPS: list[str] = Field(default=["127.0.0.1"])  # ✅ 白名单

    class Config:
        env_file = ".env"  # ✅ 支持 .env 环境变量


settings = Settings()
