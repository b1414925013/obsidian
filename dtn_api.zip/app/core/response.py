from typing import Any, Type, Optional, List, Union
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from sqlalchemy.orm import DeclarativeMeta

class ApiResponse(JSONResponse):
    def __init__(
        self,
        data: Any = None,
        message: str = "success",
        code: int = 200,
        schema: Optional[Type[BaseModel]] = None,
        **kwargs
    ):
        # 自动处理 ORM / Pydantic 对象
        if data is not None:
            data = self._convert(data, schema)

        content = {
            "code": code,
            "message": message,
            "data": data,
        }
        super().__init__(content=content, **kwargs)

    def _convert(self, item: Any, schema: Optional[Type[BaseModel]]):
        # 已经是 Pydantic 模型
        if isinstance(item, BaseModel):
            return item.model_dump()
        # ORM 单个对象
        elif schema and isinstance(item.__class__, DeclarativeMeta):
            return schema.model_validate(item).model_dump()
        # ORM 列表
        elif isinstance(item, list):
            return [self._convert(i, schema) for i in item]
        return item
