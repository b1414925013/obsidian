from fastapi import FastAPI
from app.routers import user_router, auth_router, nebula_router
from app.database import Base, engine

Base.metadata.create_all(bind=engine)
app = FastAPI(title="用户管理 API",
              description="""
    这是一个用户管理系统的 API 文档。
    可以实现用户的创建、查询、更新和删除等操作。
    """,
              version="1.0.0",
              terms_of_service="https://example.com/terms/",
              contact={
                  "name": "API 支持",
                  "url": "https://example.com/support",
                  "email": "support@example.com",
              },
              license_info={
                  "name": "MIT License",
                  "url": "https://opensource.org/licenses/MIT",
              }, )

# 注册路由
app.include_router(user_router.router, prefix="/users", tags=["Users"])
app.include_router(auth_router.router, prefix="/auth", tags=["Auth"])
app.include_router(nebula_router.router, prefix="/nebula", tags=["Nebula"])


@app.get("/health")
def health_check():
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="debug", reload=False)
