```shell
uvicorn app.main:app --log-level debug
uvicorn app.main:app --reload --log-level debug
```