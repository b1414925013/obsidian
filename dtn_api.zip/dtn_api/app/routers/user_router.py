from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.response import ApiResponse
from app.database import get_db
from app.schemas.user import UserCreate, UserOut
from app.services import user_service
from app.core.security import jwt_required

router = APIRouter()


@router.post("/", dependencies=[Depends(jwt_required)])
def create_user(user: UserCreate, db: Session = Depends(get_db)):
    db_user = user_service.create_user(db, user)
    return ApiResponse(data=db_user, schema=UserOut)  # ✅ 自动转 schema


@router.get("/", dependencies=[Depends(jwt_required)])
def list_users(db: Session = Depends(get_db)):
    db_users = user_service.get_users(db)
    return ApiResponse(data=db_users, schema=UserOut)  # ✅ ORM list -> 自动转
