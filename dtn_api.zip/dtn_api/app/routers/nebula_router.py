from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.response import ApiResponse
from app.database import get_db
from app.schemas.user import UserCreate, UserOut
from app.services import user_service
from app.core.security import jwt_required

router = APIRouter()


@router.post("/get_password", dependencies=[Depends(jwt_required)])
def fetch_password():
    pass
