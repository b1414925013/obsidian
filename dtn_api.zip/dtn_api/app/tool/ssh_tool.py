import os
import sys
import time
import paramiko
from sshtunnel import SSHTunnelForwarder
from typing import List, Tuple, Optional
from pathlib import Path


class SSHClient:
    def __init__(
        self,
        host: str,
        username: str,
        password: str = None,
        key_filepath: str = None,
        port: int = 22,
        log_file: Optional[str] = None,
    ):
        self.host = host
        self.username = username
        self.password = password
        self.key_filepath = key_filepath
        self.port = port
        self.client = None
        self.log_file = log_file

    def _log(self, msg: str):
        """打印/记录日志"""
        print(msg)
        if self.log_file:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(msg + "\n")

    def connect(self):
        """建立 SSH 连接"""
        try:
            self.client = paramiko.SSHClient()
            self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

            if self.key_filepath:
                private_key = paramiko.RSAKey.from_private_key_file(self.key_filepath)
                self.client.connect(
                    self.host, port=self.port, username=self.username, pkey=private_key
                )
            else:
                self.client.connect(
                    self.host,
                    port=self.port,
                    username=self.username,
                    password=self.password,
                )

            self._log(f"✅ Connected to {self.host}")
        except Exception as e:
            self._log(f"❌ Failed to connect {self.host}: {e}")
            raise

    def close(self):
        """关闭 SSH 连接"""
        if self.client:
            self.client.close()
            self._log(f"🔒 Connection to {self.host} closed.")

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()

    def execute_command(
        self, command: str, timeout: int = None, realtime: bool = False
    ) -> Tuple[int, str, str]:
        """
        执行 Shell 命令
        :param command: 命令字符串
        :param timeout: 超时时间（秒）
        :param realtime: 是否实时输出
        :return: (exit_code, stdout, stderr)
        """
        stdin, stdout, stderr = self.client.exec_command(command, timeout=timeout)

        if realtime:
            for line in iter(stdout.readline, ""):
                sys.stdout.write(line)
                sys.stdout.flush()

        exit_code = stdout.channel.recv_exit_status()
        out = stdout.read().decode("utf-8")
        err = stderr.read().decode("utf-8")
        return exit_code, out, err

    def batch_execute(self, commands: List[str], stop_on_error: bool = True):
        """批量执行命令"""
        results = []
        for cmd in commands:
            self._log(f"➡️ Executing: {cmd}")
            code, out, err = self.execute_command(cmd, realtime=True)
            results.append((cmd, code, out, err))
            if stop_on_error and code != 0:
                break
        return results

    def upload_file(self, local_path: str, remote_path: str):
        """上传文件"""
        sftp = self.client.open_sftp()
        sftp.put(local_path, remote_path)
        sftp.close()
        self._log(f"⬆️ Uploaded {local_path} → {remote_path}")

    def download_file(self, remote_path: str, local_path: str):
        """下载文件"""
        sftp = self.client.open_sftp()
        sftp.get(remote_path, local_path)
        sftp.close()
        self._log(f"⬇️ Downloaded {remote_path} → {local_path}")

    def upload_dir(self, local_dir: str, remote_dir: str):
        """上传目录（递归）"""
        sftp = self.client.open_sftp()
        for root, _, files in os.walk(local_dir):
            rel_path = os.path.relpath(root, local_dir)
            remote_path = os.path.join(remote_dir, rel_path).replace("\\", "/")
            try:
                sftp.mkdir(remote_path)
            except IOError:
                pass
            for f in files:
                sftp.put(os.path.join(root, f), f"{remote_path}/{f}")
        sftp.close()
        self._log(f"📂 Uploaded directory {local_dir} → {remote_dir}")

    def download_dir(self, remote_dir: str, local_dir: str):
        """下载目录（递归）"""
        sftp = self.client.open_sftp()

        def _download_dir(r_dir, l_dir):
            os.makedirs(l_dir, exist_ok=True)
            for item in sftp.listdir_attr(r_dir):
                r_path = f"{r_dir}/{item.filename}"
                l_path = os.path.join(l_dir, item.filename)
                if str(item.st_mode).startswith("4"):  # 目录
                    _download_dir(r_path, l_path)
                else:
                    sftp.get(r_path, l_path)

        _download_dir(remote_dir, local_dir)
        sftp.close()
        self._log(f"📂 Downloaded directory {remote_dir} → {local_dir}")


class SSHMultiJumpClient(SSHClient):
    """
    支持多级跳板机
    """

    def __init__(self, jump_chain: List[dict], **kwargs):
        """
        :param jump_chain: 跳板机链路配置
               e.g. [{"host": "jump1", "username": "u1", "password": "p1"},
                     {"host": "jump2", "username": "u2", "password": "p2"}]
        """
        super().__init__(**kwargs)
        self.jump_chain = jump_chain
        self.tunnels = []

    def connect(self):
        """通过多级跳板机建立连接"""
        bind_host, bind_port = self.host, self.port

        for j in reversed(self.jump_chain):
            tunnel = SSHTunnelForwarder(
                (j["host"], j.get("port", 22)),
                ssh_username=j["username"],
                ssh_password=j.get("password"),
                remote_bind_address=(bind_host, bind_port),
            )
            tunnel.start()
            self.tunnels.append(tunnel)
            bind_host, bind_port = "127.0.0.1", tunnel.local_bind_port

        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.client.connect(bind_host, port=bind_port, username=self.username, password=self.password)
        self._log(f"✅ Connected to {self.host} via {len(self.jump_chain)} jump hosts")

    def close(self):
        """关闭连接"""
        if self.client:
            self.client.close()
        for t in self.tunnels:
            t.stop()
        self._log("🔒 All connections closed.")
