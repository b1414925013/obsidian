from sqlalchemy.orm import Session
from app.models.user import User
from app.schemas.user import UserCreate  # ✅ 直接导入
from app.core.security import hash_password


def create_user(db: Session, user: UserCreate):
    db_user = User(
        username=user.username,
        password_hash=hash_password(user.password),
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


def get_users(db: Session):
    return db.query(User).all()
