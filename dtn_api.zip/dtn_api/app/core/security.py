from datetime import datetime, timedelta
from typing import Optional

from jose import JWTError, jwt
from passlib.context import CryptContext

from fastapi import Depends
from app.core.config import settings
from fastapi.security import OAuth2
from fastapi.security.utils import get_authorization_scheme_param
from fastapi import Request, status, HTTPException


def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def decode_access_token(token: str):
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        return payload
    except JWTError:
        return None


# ✅ JWT + IP 白名单依赖
class OAuth2WithIPWhitelist(OAuth2):
    def __init__(self):
        super().__init__(auto_error=False)  # 关闭自动报错，手动控制

    async def __call__(self, request: Request) -> Optional[str]:
        client_ip = request.client.host

        # 白名单IP直接跳过token检查
        if client_ip in settings.WHITE_LIST_IPS:
            return None  # 用None标记白名单

        # 非白名单IP，正常提取token
        authorization: str = request.headers.get("Authorization")
        scheme, token = get_authorization_scheme_param(authorization)

        if not authorization or scheme.lower() != "bearer":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="无效的认证方案（需使用Bearer）",
                headers={"WWW-Authenticate": "Bearer"},
            )

        if not token:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="缺少token",
                headers={"WWW-Authenticate": "Bearer"},
            )

        return token


# 实例化自定义的OAuth2类
oauth2_with_ip_whitelist = OAuth2WithIPWhitelist()


# 修改jwt_required依赖
def jwt_required(token: Optional[str] = Depends(oauth2_with_ip_whitelist)):
    # 如果token为None，说明是白名单IP
    if token is None:
        return {"sub": "whitelisted_ip"}

    # 验证token
    payload = decode_access_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="无效或过期的token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return payload


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)
