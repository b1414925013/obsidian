```shell
uvicorn app.main:app --log-level debug
uvicorn app.main:app --reload --log-level debug
```

### Makefile使用说明
```bazaar
联网构建
make build

下载离线依赖
make wheelhouse

离线构建
make offline-build

直接运行 FastAPI
make run

清理旧构建
make clean

生成最终发布包
make release
```