/**
 * 开发者工具箱 - 前端通用工具函数
 */

// 创建工具命名空间
const ToolUtils = {
    /**
     * 复制文本到剪贴板
     * @param {string} text - 要复制的文本
     * @param {HTMLElement} [buttonElement] - 点击的按钮元素，用于显示反馈
     * @returns {Promise<void>} - 返回Promise
     */
    copyToClipboard: async function(text, buttonElement = null) {
        try {
            if (navigator.clipboard) {
                await navigator.clipboard.writeText(text);
                this.showCopyFeedback(buttonElement);
            } else {
                this.fallbackCopyToClipboard(text, buttonElement);
            }
        } catch (err) {
            console.error('复制失败:', err);
            // 降级方案：使用传统的复制方法
            this.fallbackCopyToClipboard(text, buttonElement);
        }
    },

    /**
     * 降级的复制文本方法（当Clipboard API不支持时使用）
     * @param {string} text - 要复制的文本
     * @param {HTMLElement} [buttonElement] - 点击的按钮元素，用于显示反馈
     */
    fallbackCopyToClipboard: function(text, buttonElement = null) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        
        // 避免在移动设备上弹出键盘
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            const successful = document.execCommand('copy');
            if (successful && buttonElement) {
                this.showCopyFeedback(buttonElement);
            }
        } catch (err) {
            console.error('Fallback: Oops, unable to copy', err);
        }
        
        document.body.removeChild(textArea);
    },

    /**
     * 显示复制成功的视觉反馈
     * @param {HTMLElement} buttonElement - 按钮元素
     */
    showCopyFeedback: function(buttonElement) {
        if (!buttonElement) return;
        
        const originalText = buttonElement.textContent;
        buttonElement.textContent = '已复制!';
        buttonElement.classList.add('copied');
        
        setTimeout(() => {
            buttonElement.textContent = originalText;
            buttonElement.classList.remove('copied');
        }, 2000);
    },

    /**
     * 显示错误信息
     * @param {HTMLElement} errorElement - 错误消息元素
     * @param {string} message - 错误消息内容
     */
    showError: function(errorElement, message) {
        if (!errorElement) return;
        
        errorElement.textContent = message;
        errorElement.style.display = 'block';
    },

    /**
     * 隐藏错误信息
     * @param {HTMLElement} errorElement - 错误消息元素
     */
    hideError: function(errorElement) {
        if (!errorElement) return;
        
        errorElement.style.display = 'none';
    },

    /**
     * 清空表单输入
     * @param {Array<HTMLElement>} elements - 要清空的元素列表
     */
    clearFormInputs: function(elements) {
        elements.forEach(element => {
            if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                element.value = '';
            } else {
                element.textContent = '';
            }
        });
    },

    /**
     * 发送API请求的通用函数
     * @param {string} endpoint - API端点路径
     * @param {object} data - 要发送的数据
     * @param {function} onSuccess - 成功回调函数
     * @param {function} onError - 错误回调函数
     * @param {string} method - HTTP方法，默认为POST
     */
    sendApiRequest: async function(endpoint, data, onSuccess, onError, method = 'POST') {
        try {
            const options = {
                method: method,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            };
            
            // 准备请求体
            if (data && method === 'POST') {
                const formData = new URLSearchParams();
                for (const [key, value] of Object.entries(data)) {
                    formData.append(key, value);
                }
                options.body = formData;
            }
            
            const response = await fetch(endpoint, options);
            const result = await response.json();
            
            if (result.success || result.valid !== false) {
                onSuccess(result);
            } else {
                onError(result.error || '操作失败');
            }
        } catch (error) {
            onError('网络请求失败: ' + error.message);
        }
    },

    /**
     * 发送JSON格式的API请求
     * @param {string} endpoint - API端点路径
     * @param {object} data - 要发送的JSON数据
     * @param {function} onSuccess - 成功回调函数
     * @param {function} onError - 错误回调函数
     */
    sendJsonApiRequest: async function(endpoint, data, onSuccess, onError) {
        try {
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            
            const result = await response.json();
            
            if (result.success || result.valid !== false) {
                onSuccess(result);
            } else {
                onError(result.error || '操作失败');
            }
        } catch (error) {
            onError('网络请求失败: ' + error.message);
        }
    },

    /**
     * 防抖函数
     * @param {function} func - 要防抖的函数
     * @param {number} wait - 等待时间（毫秒）
     * @returns {function} - 防抖后的函数
     */
    debounce: function(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
};