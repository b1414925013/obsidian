document.addEventListener('DOMContentLoaded', function() {
    // 获取轮播相关元素
    const carousel = document.querySelector('.carousel');
    const carouselInner = document.querySelector('.carousel-inner');
    const carouselPages = document.querySelectorAll('.carousel-page');
    const prevBtn = document.querySelector('.carousel-btn.prev');
    const nextBtn = document.querySelector('.carousel-btn.next');
    const dotsContainer = document.querySelector('.carousel-dots');
    
    // 检查是否存在轮播元素
    if (!carousel || !carouselInner || !carouselPages.length) {
        return;
    }
    
    // 初始化轮播参数
    let currentPage = 0;
    const totalPages = carouselPages.length;
    
    // 创建分页指示器
    if (dotsContainer && totalPages > 1) {
        dotsContainer.innerHTML = '';
        for (let i = 0; i < totalPages; i++) {
            const dot = document.createElement('span');
            dot.classList.add('dot');
            if (i === currentPage) {
                dot.classList.add('active');
            }
            dot.dataset.page = i;
            dotsContainer.appendChild(dot);
            
            // 添加点击事件
            dot.addEventListener('click', function() {
                currentPage = parseInt(this.dataset.page);
                updateCarousel();
            });
        }
    }
    
    // 更新轮播状态
    function updateCarousel() {
        // 更新轮播位置
        const translateValue = -currentPage * 100;
        carouselInner.style.transform = `translateX(${translateValue}%)`;
        
        // 更新分页指示器
        if (dotsContainer) {
            const dots = dotsContainer.querySelectorAll('.dot');
            dots.forEach((dot, index) => {
                if (index === currentPage) {
                    dot.classList.add('active');
                } else {
                    dot.classList.remove('active');
                }
            });
        }
        
        // 更新按钮状态
        if (prevBtn && nextBtn) {
            prevBtn.disabled = currentPage === 0;
            nextBtn.disabled = currentPage === totalPages - 1;
            
            if (currentPage === 0) {
                prevBtn.classList.add('disabled');
            } else {
                prevBtn.classList.remove('disabled');
            }
            
            if (currentPage === totalPages - 1) {
                nextBtn.classList.add('disabled');
            } else {
                nextBtn.classList.remove('disabled');
            }
        }
    }
    
    // 上一页
    if (prevBtn) {
        prevBtn.addEventListener('click', function() {
            if (currentPage > 0) {
                currentPage--;
                updateCarousel();
            }
        });
    }
    
    // 下一页
    if (nextBtn) {
        nextBtn.addEventListener('click', function() {
            if (currentPage < totalPages - 1) {
                currentPage++;
                updateCarousel();
            }
        });
    }
    
    // 触摸滑动支持
    let touchStartX = 0;
    let touchEndX = 0;
    
    carousel.addEventListener('touchstart', function(e) {
        touchStartX = e.changedTouches[0].screenX;
    }, false);
    
    carousel.addEventListener('touchend', function(e) {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
    }, false);
    
    function handleSwipe() {
        const swipeThreshold = 50; // 最小滑动距离
        
        if (touchEndX < touchStartX - swipeThreshold) {
            // 向左滑动，下一页
            if (currentPage < totalPages - 1) {
                currentPage++;
                updateCarousel();
            }
        } else if (touchEndX > touchStartX + swipeThreshold) {
            // 向右滑动，上一页
            if (currentPage > 0) {
                currentPage--;
                updateCarousel();
            }
        }
    }
    
    // 键盘导航
    document.addEventListener('keydown', function(e) {
        if (e.key === 'ArrowLeft') {
            if (currentPage > 0) {
                currentPage--;
                updateCarousel();
            }
        } else if (e.key === 'ArrowRight') {
            if (currentPage < totalPages - 1) {
                currentPage++;
                updateCarousel();
            }
        }
    });
    
    // 初始化
    updateCarousel();
    
    // 工具卡片点击事件
    const toolCards = document.querySelectorAll('.tool-card');
    toolCards.forEach(card => {
        card.addEventListener('click', function() {
            const toolId = this.dataset.toolId;
            if (toolId) {
                // 全局替换所有下划线为连字符
                window.location.href = `/${toolId.replace(/_/g, '-')}`;
            }
        });
    });
    
    // 复制功能
    const copyButtons = document.querySelectorAll('.copy-btn');
    copyButtons.forEach(button => {
        button.addEventListener('click', function() {
            const targetId = this.dataset.target;
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                // 优先使用存储的原始结果，如果没有则使用textContent
                const textToCopy = targetElement.dataset.rawResult || targetElement.textContent || targetElement.innerText;
                
                navigator.clipboard.writeText(textToCopy).then(() => {
                    // 显示复制成功的视觉反馈
                    this.classList.add('copied');
                    setTimeout(() => {
                        this.classList.remove('copied');
                    }, 2000);
                }).catch(err => {
                    console.error('复制失败:', err);
                });
            }
        });
    });
});