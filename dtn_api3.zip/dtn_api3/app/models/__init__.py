# 数据模型模块
# 这个模块用于定义应用程序中使用的数据模型

# 示例基础模型类
class BaseModel:
    """所有模型的基类，提供通用功能"""
    def to_dict(self):
        """将模型转换为字典格式"""
        return self.__dict__

    def from_dict(self, data):
        """从字典加载模型数据"""
        for key, value in data.items():
            if hasattr(self, key):
                setattr(self, key, value)
        return self

# 未来可以在这里添加各种数据模型类，如User, Log等