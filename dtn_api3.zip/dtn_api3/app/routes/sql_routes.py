from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

# 创建SQL工具路由
sql_router = APIRouter(prefix="", tags=["sql_tools"])

# 配置模板目录
templates = Jinja2Templates(directory="app/templates")

# 导入工具函数和错误处理
from app.utils.sql_utils import format_sql, validate_sql
from app.utils.error_utils import handle_generic_error

# SQL格式化工具路由
@sql_router.get("/sql-formatter", response_class=HTMLResponse)
async def get_sql_formatter(request: Request):
    return templates.TemplateResponse("sql_formatter.html", {"request": request})

# SQL格式化API端点
@sql_router.post("/api/format-sql")
async def api_format_sql(sql: str = Form(...), indent_size: int = Form(2), uppercase_keywords: bool = Form(True), max_line_length: int = Form(100)):
    try:
        result = format_sql(sql, indent_size, uppercase_keywords, max_line_length)
        return result
    except Exception as e:
        return handle_generic_error(e, "SQL格式化失败")

# SQL语法验证API端点
@sql_router.post("/api/validate-sql")
async def api_validate_sql(sql: str = Form(...)):
    try:
        result = validate_sql(sql)
        return result
    except Exception as e:
        return {
            "valid": False,
            "error": f"SQL验证失败: {str(e)}"
        }