from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

# 创建Base64工具路由
base64_router = APIRouter(prefix="", tags=["base64_tools"])

# 配置模板目录
templates = Jinja2Templates(directory="app/templates")

# 导入工具函数和错误处理
from app.utils.base64_utils import encode_to_base64, decode_from_base64
from app.utils.error_utils import handle_validation_error

# Base64编解码工具路由
@base64_router.get("/base64-tool", response_class=HTMLResponse)
async def get_base64_tool(request: Request):
    return templates.TemplateResponse("base64_tool.html", {"request": request})

@base64_router.post("/api/base64-encode")
async def api_base64_encode(text: str = Form(...)):
    try:
        encoded = encode_to_base64(text)
        return {"success": True, "result": encoded}
    except ValueError as e:
        return handle_validation_error(e)

@base64_router.post("/api/base64-decode")
async def api_base64_decode(b64_str: str = Form(...)):
    try:
        decoded = decode_from_base64(b64_str)
        return {"success": True, "result": decoded}
    except ValueError as e:
        return handle_validation_error(e)