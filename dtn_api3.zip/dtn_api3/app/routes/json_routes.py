from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

# 创建JSON工具路由
json_router = APIRouter(prefix="", tags=["json_tools"])

# 配置模板目录
templates = Jinja2Templates(directory="app/templates")

# 导入工具函数和错误处理
from app.utils.json_utils import format_json, extract_jsonpath
from app.utils.error_utils import handle_json_error

# JSON格式化工具路由
@json_router.get("/json-formatter", response_class=HTMLResponse)
async def get_json_formatter(request: Request):
    return templates.TemplateResponse("json_formatter.html", {"request": request})

@json_router.post("/api/format-json")
async def api_format_json(json_str: str = Form(...)):
    try:
        formatted = format_json(json_str)
        return {"success": True, "result": formatted}
    except ValueError as e:
        return handle_json_error(e)

# JSONPath校验与提取工具路由
@json_router.get("/jsonpath-checker", response_class=HTMLResponse)
async def get_jsonpath_checker(request: Request):
    return templates.TemplateResponse("jsonpath_checker.html", {"request": request})

@json_router.post("/api/jsonpath-extract")
async def api_jsonpath_extract(json_str: str = Form(...), jsonpath_expr: str = Form(...)):
    return extract_jsonpath(json_str, jsonpath_expr)