from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

# 创建正则表达式工具路由
regex_router = APIRouter(prefix="", tags=["regex_tools"])

# 配置模板目录
templates = Jinja2Templates(directory="app/templates")

# 导入工具函数和错误处理
from app.utils.regex_utils import test_regex
from app.utils.error_utils import handle_generic_error

# 正则表达式测试器路由
@regex_router.get("/regex-tester", response_class=HTMLResponse)
async def get_regex_tester(request: Request):
    return templates.TemplateResponse("regex_tester.html", {"request": request})

# 测试正则表达式的API端点
@regex_router.post("/api/test-regex")
async def api_test_regex(pattern: str = Form(...), text: str = Form(...), flags: str = Form("")):
    try:
        result = test_regex(pattern, text, flags)
        return result
    except Exception as e:
        return handle_generic_error(e, "正则表达式处理失败")