from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

# 创建HTTP工具路由
http_router = APIRouter(prefix="", tags=["http_tools"])

# 配置模板目录
templates = Jinja2Templates(directory="app/templates")

# 导入工具函数和错误处理
from app.utils.http_utils import send_http_request

# HTTP请求模拟器路由
@http_router.get("/http-client", response_class=HTMLResponse)
async def get_http_client(request: Request):
    return templates.TemplateResponse("http_client.html", {"request": request})

# HTTP请求模拟器API端点
@http_router.post("/api/send-http-request")
async def api_send_http_request(request: Request):
    try:
        # 解析请求体中的JSON数据
        request_data = await request.json()
        
        # 从请求数据中提取参数
        url = request_data.get('url', '')
        method = request_data.get('method', 'GET')
        headers = request_data.get('headers', {})
        params = request_data.get('params', {})
        data = request_data.get('data')
        json_data = request_data.get('json_data')
        timeout = request_data.get('timeout', 30)
        verify_ssl = request_data.get('verify_ssl', True)
        
        # 验证必要参数
        if not url:
            return {
                'success': False,
                'error': 'URL地址不能为空'
            }
        
        # 调用工具函数发送HTTP请求
        result = await send_http_request(
            url=url,
            method=method,
            headers=headers,
            params=params,
            data=data,
            json_data=json_data,
            timeout=timeout,
            verify_ssl=verify_ssl
        )
        
        return result
    except Exception as e:
        return {
            'success': False,
            'error': f'发送HTTP请求失败: {str(e)}',
            'error_type': 'UnknownError',
            'request_info': {}
        }