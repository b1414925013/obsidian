from fastapi import APIRouter, Request
from pydantic import BaseModel, Field
from typing import List, Dict

# 导入工具函数
from app.utils.random_utils import generate_multiple_sets

# 创建随机字符串工具路由
random_router = APIRouter(prefix="", tags=["random_tools"])


class RandomRequest(BaseModel):
    """
    随机字符串请求模型
    """
    num: int = Field(default=1, description="要生成的随机字符串集合数量")
    length: int = Field(default=8, description="每种随机字符串的长度（除UUID外）")


@random_router.post("/api/get_random_strings")
async def api_get_random_strings(request_data: RandomRequest) -> List[Dict[str, str]]:
    """
    根据请求体参数生成指定数量的随机字符串组
    每组包含7种不同类型的随机字符串，长度可配置
    """
    # 调用工具函数生成随机字符串集合
    # 注意：这里我们不使用Pydantic的内置验证，而是使用工具函数中的验证逻辑
    # 以确保符合用户要求的边界情况处理（如num不是正整数则设为1等）
    return generate_multiple_sets(request_data.num, request_data.length)