from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import base64

# 创建QRCode工具路由
qrcode_router = APIRouter(prefix="", tags=["qrcode_tools"])

# 配置模板目录
templates = Jinja2Templates(directory="app/templates")

# 导入工具函数和错误处理
from app.utils.qrcode_utils import generate_qrcode
from app.utils.error_utils import handle_validation_error

# 二维码生成器路由
@qrcode_router.get("/qrcode-generator", response_class=HTMLResponse)
async def get_qrcode_generator(request: Request):
    return templates.TemplateResponse("qrcode_generator.html", {"request": request})

@qrcode_router.post("/api/generate-qrcode")
async def api_generate_qrcode(data: str = Form(...)):
    try:
        qr_bytes = generate_qrcode(data)
        # 转换为base64字符串用于前端显示
        qr_base64 = base64.b64encode(qr_bytes).decode('utf-8')
        return {"success": True, "qr_code": qr_base64}
    except ValueError as e:
        return handle_validation_error(e)