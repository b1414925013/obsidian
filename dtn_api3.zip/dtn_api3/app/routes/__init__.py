from fastapi import APIRouter

from fastapi import APIRouter

# 导入所有工具路由
from app.routes.json_routes import json_router
from app.routes.base64_routes import base64_router
from app.routes.qrcode_routes import qrcode_router
from app.routes.time_routes import time_router
from app.routes.regex_routes import regex_router
from app.routes.text_diff_routes import text_diff_router
from app.routes.sql_routes import sql_router
from app.routes.http_routes import http_router
from app.routes.naming_routes import naming_router
from app.routes.random_string_routes import random_router

# 创建主工具路由
router = APIRouter()

# 注册所有工具路由
router.include_router(json_router)
router.include_router(base64_router)
router.include_router(qrcode_router)
router.include_router(time_router)
router.include_router(regex_router)
router.include_router(text_diff_router)
router.include_router(sql_router)
router.include_router(http_router)
router.include_router(naming_router)
router.include_router(random_router)