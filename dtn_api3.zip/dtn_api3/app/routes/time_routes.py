from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

# 创建时间戳工具路由
time_router = APIRouter(prefix="", tags=["time_tools"])

# 配置模板目录
templates = Jinja2Templates(directory="app/templates")

# 导入工具函数和错误处理
from app.utils.time_utils import timestamp_to_datetime, detect_timestamp_type, datetime_to_timestamp
from app.utils.error_utils import handle_validation_error, handle_generic_error

# 时间戳转换工具路由
@time_router.get("/timestamp-converter", response_class=HTMLResponse)
async def get_timestamp_converter(request: Request):
    return templates.TemplateResponse("timestamp_converter.html", {"request": request})

@time_router.post("/api/timestamp-to-datetime")
async def api_timestamp_to_datetime(timestamp: str = Form(...), timestamp_type: str = Form(...), timezone: str = Form(...)):
    try:
        # 处理时间戳类型
        is_milliseconds = False
        if timestamp_type == 'milliseconds':
            is_milliseconds = True
        elif timestamp_type == 'auto':
            # 自动检测时间戳类型
            ts_type = detect_timestamp_type(timestamp)
            is_milliseconds = (ts_type == 'milliseconds')
        
        # 转换时间戳
        result = timestamp_to_datetime(timestamp, is_milliseconds, timezone)
        return {"success": True, "result": result}
    except ValueError as e:
        return handle_validation_error(e)
    except Exception as e:
        return handle_generic_error(e)

@time_router.post("/api/datetime-to-timestamp")
async def api_datetime_to_timestamp(datetime: str = Form(...), format: str = Form(...), output_type: str = Form(...)):
    try:
        # 处理输出类型
        is_milliseconds = (output_type == 'milliseconds')
        
        # 转换时间
        result = datetime_to_timestamp(datetime, format, is_milliseconds)
        return {"success": True, "result": result}
    except ValueError as e:
        return handle_validation_error(e)
    except Exception as e:
        return handle_generic_error(e)