from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

# 创建变量命名格式转换工具路由
naming_router = APIRouter(prefix="", tags=["naming_tools"])

# 配置模板目录
templates = Jinja2Templates(directory="app/templates")

# 导入工具函数和错误处理
from app.utils.naming_utils import convert_all_formats
from app.utils.error_utils import handle_validation_error, handle_generic_error

# 变量命名格式转换工具路由
@naming_router.get("/naming-converter", response_class=HTMLResponse)
async def get_naming_converter(request: Request):
    return templates.TemplateResponse("naming_converter.html", {"request": request})

@naming_router.post("/api/convert-naming-format")
async def api_convert_naming_format(text: str = Form(...)):
    try:
        # 执行所有格式的转换
        results = convert_all_formats(text)
        return {"success": True, "results": results}
    except ValueError as e:
        return handle_validation_error(e)
    except Exception as e:
        return handle_generic_error(e)