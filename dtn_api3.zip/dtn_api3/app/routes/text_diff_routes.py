from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

# 创建文本差异对比工具路由
text_diff_router = APIRouter(prefix="", tags=["text_diff_tools"])

# 配置模板目录
templates = Jinja2Templates(directory="app/templates")

# 导入工具函数和错误处理
from app.utils.text_diff_utils import diff_texts
from app.utils.error_utils import handle_generic_error

# 文本差异对比工具路由
@text_diff_router.get("/text-diff", response_class=HTMLResponse)
async def get_text_diff(request: Request):
    return templates.TemplateResponse("text_diff.html", {"request": request})

# 文本差异对比API端点
@text_diff_router.post("/api/compare-texts")
async def api_compare_texts(text1: str = Form(...), text2: str = Form(...), context_lines: str = Form("3")):
    try:
        # 处理上下文行数
        try:
            if context_lines == "all":
                context_lines_value = 1000  # 使用一个较大的值表示显示全部
            else:
                context_lines_value = int(context_lines)
        except ValueError:
            context_lines_value = 3  # 默认显示3行上下文
        
        result = diff_texts(text1, text2, context_lines_value)
        return result
    except Exception as e:
        return handle_generic_error(e, "文本差异比较失败")