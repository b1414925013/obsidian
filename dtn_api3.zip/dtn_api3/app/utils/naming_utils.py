import re


def detect_naming_format(text: str) -> str:
    """检测命名格式
    
    Args:
        text: 输入文本
        
    Returns:
        命名格式名称
    """
    # 检查帕斯卡命名法 (PascalCase)
    if re.match(r'^[A-Z][a-zA-Z0-9]*$', text) and re.search(r'[A-Z]', text[1:]):
        return 'PascalCase'
    
    # 检查驼峰命名法 (camelCase)
    if re.match(r'^[a-z][a-zA-Z0-9]*$', text) and re.search(r'[A-Z]', text):
        return 'camelCase'
    
    # 检查下划线+大写 (SNAKE_CASE)
    if re.match(r'^[A-Z][A-Z0-9_]*$', text) and '_' in text:
        return 'SNAKE_CASE'
    
    # 检查下划线+小写 (snake_case)
    if re.match(r'^[a-z][a-z0-9_]*$', text) and '_' in text:
        return 'snake_case'
    
    # 检查中横线+小写 (kebab-case)
    if re.match(r'^[a-z][a-z0-9-]*$', text) and '-' in text:
        return 'kebab-case'
    
    # 检查包名格式 (package.name)
    if re.match(r'^[a-z][a-z0-9.]*$', text) and '.' in text:
        return 'package.name'
    
    # 默认返回未知格式
    return 'unknown'


def to_camel_case(text: str) -> str:
    """转换为驼峰命名法 (camelCase)
    
    Args:
        text: 输入文本
        
    Returns:
        驼峰命名法文本
    """
    # 处理下划线或中横线分隔的格式
    if '_' in text:
        parts = text.split('_')
    elif '-' in text:
        parts = text.split('-')
    elif '.' in text:
        parts = text.split('.')
    elif ' ' in text:
        # 处理空格分隔的自然文本格式
        parts = text.split()
    else:
        # 处理帕斯卡命名法
        if text and text[0].isupper():
            return text[0].lower() + text[1:]
        return text
    
    # 转换为驼峰命名法
    result = parts[0].lower()
    for part in parts[1:]:
        result += part.capitalize()
    
    return result


def to_pascal_case(text: str) -> str:
    """转换为帕斯卡命名法 (PascalCase)
    
    Args:
        text: 输入文本
        
    Returns:
        帕斯卡命名法文本
    """
    # 处理下划线或中横线分隔的格式
    if '_' in text:
        parts = text.split('_')
    elif '-' in text:
        parts = text.split('-')
    elif '.' in text:
        parts = text.split('.')
    elif ' ' in text:
        # 处理空格分隔的自然文本格式
        parts = text.split()
    else:
        # 处理驼峰命名法
        if text and text[0].islower():
            return text[0].upper() + text[1:]
        return text
    
    # 转换为帕斯卡命名法
    result = ''
    for part in parts:
        result += part.capitalize()
    
    return result


def to_snake_case(text: str) -> str:
    """转换为下划线+小写命名法 (snake_case)
    
    Args:
        text: 输入文本
        
    Returns:
        下划线+小写命名法文本
    """
    # 如果已经是下划线格式，直接转为小写
    if '_' in text:
        return text.lower()
    
    # 处理空格分隔的自然文本格式
    if ' ' in text:
        return text.lower().replace(' ', '_')
    
    # 处理驼峰命名法和帕斯卡命名法
    # 在大写字母前添加下划线，并转为小写
    result = re.sub(r'([A-Z])', r'_\1', text)
    # 去除开头可能的下划线
    if result.startswith('_'):
        result = result[1:]
    
    return result.lower()


def to_upper_snake_case(text: str) -> str:
    """转换为下划线+大写命名法 (SNAKE_CASE)
    
    Args:
        text: 输入文本
        
    Returns:
        下划线+大写命名法文本
    """
    return to_snake_case(text).upper()


def to_kebab_case(text: str) -> str:
    """转换为中横线+小写命名法 (kebab-case)
    
    Args:
        text: 输入文本
        
    Returns:
        中横线+小写命名法文本
    """
    # 先转换为snake_case，然后替换下划线为中横线
    return to_snake_case(text).replace('_', '-')


def to_package_name(text: str) -> str:
    """转换为包名格式 (package.name)
    
    Args:
        text: 输入文本
        
    Returns:
        包名格式文本
    """
    # 先转换为snake_case，然后替换下划线为点
    return to_snake_case(text).replace('_', '.')


def convert_all_formats(text: str) -> dict:
    """转换为所有支持的命名格式
    
    Args:
        text: 输入文本
        
    Returns:
        包含所有命名格式的字典
    """
    return {
        'original': text,
        'detected_format': detect_naming_format(text),
        'camelCase': to_camel_case(text),
        'PascalCase': to_pascal_case(text),
        'snake_case': to_snake_case(text),
        'SNAKE_CASE': to_upper_snake_case(text),
        'kebab-case': to_kebab_case(text),
        'package.name': to_package_name(text)
    }