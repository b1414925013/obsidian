import aiohttp
import json
import time
from typing import Dict, Any, Optional, Union


async def send_http_request(
    url: str,
    method: str = 'GET',
    headers: Optional[Dict[str, str]] = None,
    params: Optional[Dict[str, str]] = None,
    data: Optional[Union[Dict[str, Any], str]] = None,
    json_data: Optional[Dict[str, Any]] = None,
    timeout: int = 30,
    verify_ssl: bool = True
) -> Dict[str, Any]:
    """
    发送HTTP请求并返回响应结果
    
    Args:
        url: 请求URL
        method: 请求方法（GET, POST, PUT, DELETE等）
        headers: 请求头
        params: URL查询参数
        data: 表单数据或原始字符串数据
        json_data: JSON数据（如果设置，将自动设置Content-Type为application/json）
        timeout: 请求超时时间（秒）
        verify_ssl: 是否验证SSL证书
        
    Returns:
        包含请求结果的字典
    """
    try:
        # 记录开始时间
        start_time = time.time()
        
        # 准备请求参数
        request_kwargs = {
            'params': params,
            'timeout': aiohttp.ClientTimeout(total=timeout),
            'verify_ssl': verify_ssl
        }
        
        # 添加请求头
        if headers:
            request_kwargs['headers'] = headers.copy()
        else:
            request_kwargs['headers'] = {}
        
        # 处理请求体
        if json_data is not None:
            request_kwargs['json'] = json_data
            request_kwargs['headers']['Content-Type'] = 'application/json'
        elif data is not None:
            request_kwargs['data'] = data
        
        # 创建客户端会话并发送请求
        async with aiohttp.ClientSession() as session:
            method = method.upper()
            request_func = getattr(session, method.lower(), session.get)
            
            async with request_func(url, **request_kwargs) as response:
                # 记录结束时间
                end_time = time.time()
                response_time = end_time - start_time
                
                # 获取响应内容
                content_type = response.headers.get('Content-Type', '')
                try:
                    if 'application/json' in content_type:
                        response_data = await response.json()
                    else:
                        response_data = await response.text()
                except Exception:
                    # 如果解析失败，尝试获取原始内容
                    response_data = await response.read()
                    if isinstance(response_data, bytes):
                        # 尝试解码为字符串，如果失败则保留字节格式
                        try:
                            response_data = response_data.decode('utf-8', errors='replace')
                        except:
                            response_data = str(response_data)
                
                # 构建结果
                result = {
                    'success': True,
                    'status_code': response.status,
                    'reason': response.reason,
                    'headers': dict(response.headers),
                    'data': response_data,
                    'response_time': response_time,
                    'url': str(response.url),
                    'request_info': {
                        'method': method,
                        'original_url': url,
                        'headers': request_kwargs['headers'],
                        'params': params,
                        'has_data': data is not None,
                        'has_json': json_data is not None
                    }
                }
                
                return result
    except aiohttp.ClientError as e:
        # 网络相关错误
        return {
            'success': False,
            'error_type': 'ClientError',
            'error': str(e),
            'request_info': {
                'method': method,
                'url': url
            }
        }
    except asyncio.TimeoutError:
        # 请求超时错误
        return {
            'success': False,
            'error_type': 'TimeoutError',
            'error': f'请求超时（{timeout}秒）',
            'request_info': {
                'method': method,
                'url': url
            }
        }
    except Exception as e:
        # 其他错误
        return {
            'success': False,
            'error_type': 'UnknownError',
            'error': str(e),
            'request_info': {
                'method': method,
                'url': url
            }
        }


def format_response_for_display(response_data: Any) -> str:
    """
    格式化响应数据以便显示
    
    Args:
        response_data: 响应数据
        
    Returns:
        格式化后的字符串
    """
    if isinstance(response_data, dict) or isinstance(response_data, list):
        # JSON数据，格式化显示
        try:
            return json.dumps(response_data, ensure_ascii=False, indent=2)
        except:
            pass
    elif isinstance(response_data, bytes):
        # 字节数据，尝试解码
        try:
            return response_data.decode('utf-8', errors='replace')
        except:
            return str(response_data)
    
    # 其他类型，转为字符串
    return str(response_data)


def parse_headers(headers_str: str) -> Dict[str, str]:
    """
    从字符串解析HTTP请求头
    
    Args:
        headers_str: 包含请求头的字符串，每行一个请求头，格式为 "Key: Value"
        
    Returns:
        请求头字典
    """
    headers = {}
    if not headers_str:
        return headers
    
    lines = headers_str.strip().split('\n')
    for line in lines:
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        
        # 查找第一个冒号作为分隔符
        colon_pos = line.find(':')
        if colon_pos > 0:
            key = line[:colon_pos].strip()
            value = line[colon_pos + 1:].strip()
            headers[key] = value
    
    return headers


def parse_query_params(params_str: str) -> Dict[str, str]:
    """
    从字符串解析URL查询参数
    
    Args:
        params_str: 查询参数字符串，可以是以&分隔的键值对或URL编码格式
        
    Returns:
        查询参数字典
    """
    params = {}
    if not params_str:
        return params
    
    # 如果字符串以?开头，去掉
    if params_str.startswith('?'):
        params_str = params_str[1:]
    
    # 分割键值对
    pairs = params_str.split('&')
    for pair in pairs:
        if '=' in pair:
            key, value = pair.split('=', 1)
            params[key.strip()] = value.strip()
        else:
            params[pair.strip()] = ''
    
    return params


def get_common_headers() -> Dict[str, str]:
    """
    获取常用的HTTP请求头
    
    Returns:
        常用请求头字典
    """
    return {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'Connection': 'keep-alive'
    }


def get_sample_requests() -> list:
    """
    获取HTTP请求示例
    
    Returns:
        请求示例列表
    """
    return [
        {
            'name': 'GET请求示例',
            'method': 'GET',
            'url': 'https://jsonplaceholder.typicode.com/posts/1',
            'headers': 'User-Agent: Mozilla/5.0\nAccept: application/json',
            'params': '',
            'data': '',
            'content_type': 'application/json',
            'description': '发送GET请求获取JSON数据'
        },
        {
            'name': 'POST请求示例',
            'method': 'POST',
            'url': 'https://jsonplaceholder.typicode.com/posts',
            'headers': 'User-Agent: Mozilla/5.0\nContent-Type: application/json',
            'params': '',
            'data': '{"title": "测试标题", "body": "测试内容", "userId": 1}',
            'content_type': 'application/json',
            'description': '发送POST请求创建资源'
        },
        {
            'name': 'PUT请求示例',
            'method': 'PUT',
            'url': 'https://jsonplaceholder.typicode.com/posts/1',
            'headers': 'User-Agent: Mozilla/5.0\nContent-Type: application/json',
            'params': '',
            'data': '{"id": 1, "title": "更新后的标题", "body": "更新后的内容", "userId": 1}',
            'content_type': 'application/json',
            'description': '发送PUT请求更新资源'
        },
        {
            'name': 'DELETE请求示例',
            'method': 'DELETE',
            'url': 'https://jsonplaceholder.typicode.com/posts/1',
            'headers': 'User-Agent: Mozilla/5.0',
            'params': '',
            'data': '',
            'content_type': 'application/json',
            'description': '发送DELETE请求删除资源'
        },
        {
            'name': '带查询参数的GET请求',
            'method': 'GET',
            'url': 'https://jsonplaceholder.typicode.com/posts',
            'headers': 'User-Agent: Mozilla/5.0\nAccept: application/json',
            'params': 'userId=1&_limit=5',
            'data': '',
            'content_type': 'application/json',
            'description': '发送带查询参数的GET请求'
        }
    ]

# 导入asyncio模块，因为send_http_request函数中使用了asyncio.TimeoutError
try:
    import asyncio
except ImportError:
    # 如果环境中没有asyncio模块，提供一个简单的替代
    class AsyncioStub:
        class TimeoutError(Exception):
            pass
    
    asyncio = AsyncioStub()