import time
from datetime import datetime, timezone, timedelta


def timestamp_to_datetime(timestamp: str, is_milliseconds: bool = False, tz: str = 'UTC') -> str:
    """将时间戳转换为可读时间格式
    
    Args:
        timestamp: 时间戳字符串
        is_milliseconds: 是否为毫秒级时间戳
        tz: 时区，支持 'UTC' 或 'CST'（北京时间，UTC+8）
        
    Returns:
        格式化的时间字符串
    """
    try:
        # 转换为整数
        ts = int(timestamp)
        
        # 处理毫秒级时间戳
        if is_milliseconds:
            ts = ts / 1000
        
        # 根据时区创建datetime对象
        if tz.upper() == 'CST':
            # 北京时间（UTC+8）
            dt = datetime.fromtimestamp(ts, timezone(timedelta(hours=8)))
        else:
            # 默认UTC时区
            dt = datetime.fromtimestamp(ts, timezone.utc)
        
        # 格式化时间
        return dt.strftime('%Y-%m-%d %H:%M:%S %Z')
    except ValueError as e:
        raise ValueError(f"无效的时间戳: {str(e)}")


def datetime_to_timestamp(datetime_str: str, format_str: str = '%Y-%m-%d %H:%M:%S', is_milliseconds: bool = False) -> str:
    """将可读时间转换为时间戳
    
    Args:
        datetime_str: 时间字符串
        format_str: 时间格式
        is_milliseconds: 是否返回毫秒级时间戳
        
    Returns:
        时间戳字符串
    """
    try:
        # 解析时间字符串
        dt = datetime.strptime(datetime_str, format_str)
        
        # 转换为时间戳
        ts = dt.timestamp()
        
        # 处理毫秒级时间戳
        if is_milliseconds:
            ts = ts * 1000
            return str(int(ts))
        else:
            return str(int(ts))
    except ValueError as e:
        raise ValueError(f"无效的时间格式: {str(e)}")


def is_timestamp(value: str) -> bool:
    """判断字符串是否为有效的时间戳
    
    Args:
        value: 输入字符串
        
    Returns:
        是否为有效时间戳
    """
    try:
        # 尝试转换为整数
        ts = int(value)
        # 检查范围是否合理（1970年至今的时间戳范围）
        return 0 <= ts <= 2147483647000  # 支持到毫秒级
    except ValueError:
        return False


def detect_timestamp_type(timestamp: str) -> str:
    """检测时间戳类型（秒级或毫秒级）
    
    Args:
        timestamp: 时间戳字符串
        
    Returns:
        'seconds' 或 'milliseconds'
    """
    try:
        ts = int(timestamp)
        # 毫秒级时间戳通常长度为13位
        if len(timestamp) == 13 and ts > 1000000000000:
            return 'milliseconds'
        else:
            return 'seconds'
    except ValueError:
        raise ValueError("无效的时间戳格式")