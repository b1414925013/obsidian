import re


def format_sql(sql: str, indent_size: int = 2, uppercase_keywords: bool = True, max_line_length: int = 100) -> dict:
    """
    格式化SQL语句，提高可读性
    
    Args:
        sql: 原始SQL语句
        indent_size: 缩进大小（空格数）
        uppercase_keywords: 是否将关键字转换为大写
        max_line_length: 最大行长度（超过后自动换行）
        
    Returns:
        包含格式化结果的字典
    """
    try:
        # 检查输入是否为空
        if not sql or not sql.strip():
            return {
                'success': True,
                'formatted_sql': '',
                'original_sql': sql,
                'changes': 0
            }
        
        original_sql = sql.strip()
        formatted_sql = original_sql
        
        # 定义SQL关键字列表
        keywords = [
            'SELECT', 'FROM', 'WHERE', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'ALTER', 'DROP',
            'TABLE', 'INDEX', 'VIEW', 'DATABASE', 'JOIN', 'INNER', 'LEFT', 'RIGHT', 'FULL',
            'OUTER', 'ON', 'AND', 'OR', 'NOT', 'IN', 'LIKE', 'BETWEEN', 'GROUP', 'BY',
            'ORDER', 'HAVING', 'LIMIT', 'OFFSET', 'AS', 'DISTINCT', 'VALUES', 'SET',
            'CASE', 'WHEN', 'THEN', 'ELSE', 'END', 'IF', 'EXISTS', 'UNION', 'ALL', 'WITH'
        ]
        
        # 保存字符串字面量，避免在字符串中的关键字被替换
        string_literals = []
        literal_counter = 0
        
        # 匹配单引号字符串
        def save_single_quote(match):
            nonlocal literal_counter
            string_literals.append(match.group(0))
            literal_counter += 1
            return f"__LITERAL_{literal_counter-1}__"
        
        # 匹配双引号字符串
        def save_double_quote(match):
            nonlocal literal_counter
            string_literals.append(match.group(0))
            literal_counter += 1
            return f"__LITERAL_{literal_counter-1}__"
        
        # 保存注释，避免注释中的关键字被替换
        comments = []
        comment_counter = 0
        
        # 匹配单行注释
        def save_single_line_comment(match):
            nonlocal comment_counter
            comments.append(match.group(0))
            comment_counter += 1
            return f"__COMMENT_{comment_counter-1}__"
        
        # 匹配多行注释
        def save_multi_line_comment(match):
            nonlocal comment_counter
            comments.append(match.group(0))
            comment_counter += 1
            return f"__COMMENT_{comment_counter-1}__"
        
        # 1. 保存注释
        formatted_sql = re.sub(r'--.*$', save_single_line_comment, formatted_sql, flags=re.MULTILINE)
        formatted_sql = re.sub(r'/\*[\s\S]*?\*/', save_multi_line_comment, formatted_sql)
        
        # 2. 保存字符串字面量
        formatted_sql = re.sub(r"'([^'\\]|\\.)*'", save_single_quote, formatted_sql)
        formatted_sql = re.sub(r'"([^"\\]|\\.)*"', save_double_quote, formatted_sql)
        
        # 3. 处理关键字和格式化
        # 添加换行符和缩进
        formatted_sql = add_line_breaks(formatted_sql, keywords, indent_size, uppercase_keywords)
        
        # 4. 恢复字符串字面量
        for i, literal in enumerate(string_literals):
            formatted_sql = formatted_sql.replace(f"__LITERAL_{i}__", literal)
        
        # 5. 恢复注释
        for i, comment in enumerate(comments):
            formatted_sql = formatted_sql.replace(f"__COMMENT_{i}__", comment)
        
        # 6. 处理行长度和格式化调整
        formatted_sql = adjust_line_length(formatted_sql, max_line_length, indent_size)
        
        # 7. 计算变更次数（简化计算，实际应该比较每行差异）
        changes = len(original_sql) - len(formatted_sql)
        
        return {
            'success': True,
            'formatted_sql': formatted_sql,
            'original_sql': original_sql,
            'changes': abs(changes) if changes != 0 else 1  # 至少算作一处变更
        }
    except Exception as e:
        return {
            'success': False,
            'error': f'SQL格式化失败: {str(e)}'
        }


def add_line_breaks(sql: str, keywords: list, indent_size: int, uppercase_keywords: bool) -> str:
    """
    在SQL语句的关键字前添加换行符和缩进
    """
    # 去除多余空白
    sql = re.sub(r'\s+', ' ', sql)
    
    # 初始化缩进级别
    indent_level = 0
    result_lines = []
    
    # 分割SQL语句为逻辑块
    sql_parts = []
    current_part = ''
    in_parentheses = 0
    
    for char in sql:
        if char == '(':
            in_parentheses += 1
        elif char == ')':
            in_parentheses -= 1
        
        current_part += char
        
        # 在SQL结束或遇到分号时分割
        if char == ';' or (char == ' ' and in_parentheses == 0 and any(keyword in current_part.upper() for keyword in keywords)):
            sql_parts.append(current_part.strip())
            current_part = ''
    
    if current_part.strip():
        sql_parts.append(current_part.strip())
    
    # 处理每个部分
    for part in sql_parts:
        if not part:
            continue
        
        # 检查是否包含关键字
        processed = False
        for keyword in keywords:
            keyword_regex = f'\\b{keyword}\\b'
            if re.search(keyword_regex, part, re.IGNORECASE):
                # 处理关键字（如SELECT, FROM, WHERE等）
                if keyword.upper() in ['SELECT', 'WITH', 'CREATE', 'ALTER', 'INSERT', 'UPDATE', 'DELETE']:
                    # 开始新的块
                    if uppercase_keywords:
                        part = re.sub(keyword_regex, keyword.upper(), part, re.IGNORECASE)
                    result_lines.append(' ' * indent_level + part)
                elif keyword.upper() in ['FROM', 'WHERE', 'GROUP', 'ORDER', 'HAVING', 'LIMIT', 'OFFSET']:
                    # 需要换行并保持相同缩进级别
                    if uppercase_keywords:
                        part = re.sub(keyword_regex, keyword.upper(), part, re.IGNORECASE)
                    result_lines.append(' ' * indent_level + part)
                elif keyword.upper() in ['JOIN', 'INNER', 'LEFT', 'RIGHT', 'FULL', 'OUTER']:
                    # 连接操作符也需要换行
                    if uppercase_keywords:
                        part = re.sub(keyword_regex, keyword.upper(), part, re.IGNORECASE)
                    result_lines.append(' ' * indent_level + part)
                elif keyword.upper() == 'ON':
                    # ON关键字需要额外缩进
                    if uppercase_keywords:
                        part = re.sub(keyword_regex, keyword.upper(), part, re.IGNORECASE)
                    result_lines.append(' ' * (indent_level + indent_size) + part)
                elif keyword.upper() == 'SET':
                    # SET关键字后增加缩进
                    if uppercase_keywords:
                        part = re.sub(keyword_regex, keyword.upper(), part, re.IGNORECASE)
                    result_lines.append(' ' * indent_level + part)
                    indent_level += indent_size
                elif keyword.upper() == 'END':
                    # END关键字需要减少缩进
                    indent_level = max(0, indent_level - indent_size)
                    if uppercase_keywords:
                        part = re.sub(keyword_regex, keyword.upper(), part, re.IGNORECASE)
                    result_lines.append(' ' * indent_level + part)
                processed = True
                break
        
        if not processed:
            # 如果不包含关键字，直接添加
            result_lines.append(' ' * indent_level + part)
    
    # 重新组合SQL语句
    formatted_sql = '\n'.join(result_lines)
    
    # 处理括号内的缩进
    formatted_sql = handle_parentheses_indentation(formatted_sql, indent_size)
    
    return formatted_sql


def handle_parentheses_indentation(sql: str, indent_size: int) -> str:
    """
    处理括号内的缩进
    """
    lines = sql.split('\n')
    result_lines = []
    indent_level = 0
    
    for line in lines:
        stripped_line = line.strip()
        
        # 减少缩进级别（在行开始处的右括号）
        closing_parentheses = len(re.findall(r'^\)', stripped_line))
        indent_level = max(0, indent_level - closing_parentheses * indent_size)
        
        # 添加当前行
        result_lines.append(' ' * indent_level + stripped_line)
        
        # 增加缩进级别（行中的左括号）
        opening_parentheses = len(re.findall(r'\(', stripped_line))
        closing_parentheses_in_line = len(re.findall(r'\)', stripped_line))
        net_parentheses = opening_parentheses - closing_parentheses_in_line
        if net_parentheses > 0:
            indent_level += net_parentheses * indent_size
    
    return '\n'.join(result_lines)


def adjust_line_length(sql: str, max_line_length: int, indent_size: int) -> str:
    """
    调整SQL语句的行长度，超过指定长度时自动换行
    """
    if max_line_length <= 0:
        return sql
    
    lines = sql.split('\n')
    result_lines = []
    
    for line in lines:
        if len(line) <= max_line_length:
            # 行长度在限制范围内，直接添加
            result_lines.append(line)
        else:
            # 行长度超过限制，需要分割
            # 尝试在逗号处分割
            parts = line.split(',')
            if len(parts) > 1:
                # 有逗号，可以在逗号后换行
                base_indent = len(line) - len(line.lstrip()) + indent_size
                result_lines.append(parts[0] + ',')
                for i in range(1, len(parts) - 1):
                    result_lines.append(' ' * base_indent + parts[i].strip() + ',')
                result_lines.append(' ' * base_indent + parts[-1].strip())
            else:
                # 没有逗号，尝试在AND/OR处分割
                or_parts = re.split(r'(\bOR\b)', line)
                if len(or_parts) > 1:
                    base_indent = len(line) - len(line.lstrip()) + indent_size
                    result_lines.append(or_parts[0].strip())
                    for i in range(1, len(or_parts), 2):
                        result_lines.append(' ' * base_indent + or_parts[i] + ' ' + or_parts[i+1].strip())
                else:
                    and_parts = re.split(r'(\bAND\b)', line)
                    if len(and_parts) > 1:
                        base_indent = len(line) - len(line.lstrip()) + indent_size
                        result_lines.append(and_parts[0].strip())
                        for i in range(1, len(and_parts), 2):
                            result_lines.append(' ' * base_indent + and_parts[i] + ' ' + and_parts[i+1].strip())
                    else:
                        # 无法分割，保持原样
                        result_lines.append(line)
    
    return '\n'.join(result_lines)


def validate_sql(sql: str) -> dict:
    """
    简单验证SQL语句的有效性
    
    Args:
        sql: 要验证的SQL语句
        
    Returns:
        包含验证结果的字典
    """
    try:
        # 检查基本语法结构
        # 这是一个简化的验证，实际应用中可能需要更复杂的解析器
        if not sql or not sql.strip():
            return {
                'valid': False,
                'error': 'SQL语句不能为空'
            }
        
        # 检查括号是否匹配
        opening_parentheses = sql.count('(')
        closing_parentheses = sql.count(')')
        if opening_parentheses != closing_parentheses:
            return {
                'valid': False,
                'error': f'括号不匹配: 有{opening_parentheses}个左括号和{closing_parentheses}个右括号'
            }
        
        # 检查字符串引号是否匹配
        single_quotes = sql.count("'")
        double_quotes = sql.count('"')
        if single_quotes % 2 != 0:
            return {
                'valid': False,
                'error': '单引号不匹配'
            }
        if double_quotes % 2 != 0:
            return {
                'valid': False,
                'error': '双引号不匹配'
            }
        
        # 检查常见关键字（简化版）
        sql_upper = sql.upper()
        if ('SELECT' in sql_upper or 'INSERT' in sql_upper or 'UPDATE' in sql_upper or 'DELETE' in sql_upper or 
            'CREATE' in sql_upper or 'ALTER' in sql_upper or 'DROP' in sql_upper):
            return {
                'valid': True,
                'message': 'SQL语句语法看起来有效'
            }
        else:
            return {
                'valid': True,
                'message': 'SQL语句语法看起来有效，但可能缺少常见关键字'
            }
    except Exception as e:
        return {
            'valid': False,
            'error': f'验证失败: {str(e)}'
        }


def get_sql_examples() -> list:
    """
    获取常用SQL语句示例
    
    Returns:
        SQL示例列表
    """
    return [
        {
            'name': '简单SELECT查询',
            'sql': 'SELECT id, name, email FROM users WHERE age > 18 ORDER BY name ASC;',
            'description': '基本的SELECT语句，从users表中选择数据'
        },
        {
            'name': 'JOIN查询',
            'sql': 'SELECT u.id, u.name, o.order_id, o.total FROM users u INNER JOIN orders o ON u.id = o.user_id WHERE o.status = \'completed\';',
            'description': '使用INNER JOIN连接users和orders表'
        },
        {
            'name': '复杂查询（带聚合函数）',
            'sql': 'SELECT c.category_name, COUNT(p.id) as product_count, AVG(p.price) as avg_price FROM categories c LEFT JOIN products p ON c.id = p.category_id GROUP BY c.category_name HAVING product_count > 5 ORDER BY avg_price DESC;',
            'description': '复杂查询，包含JOIN、聚合函数、GROUP BY和HAVING'
        },
        {
            'name': 'INSERT语句',
            'sql': 'INSERT INTO products (name, price, category_id, created_at) VALUES (\'智能手机\', 3999.00, 1, NOW()), (\'笔记本电脑\', 5999.00, 2, NOW());',
            'description': '插入多条数据到products表'
        },
        {
            'name': 'UPDATE语句',
            'sql': 'UPDATE users SET email = \'new_email@example.com\', updated_at = NOW() WHERE id = 123;',
            'description': '更新users表中的数据'
        }
    ]