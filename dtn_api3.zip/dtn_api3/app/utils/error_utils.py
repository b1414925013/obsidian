def create_error_response(error_type: str, error_message: str) -> dict:
    """
    创建统一格式的错误响应
    
    Args:
        error_type: 错误类型（字符串标识符）
        error_message: 详细的错误消息
        
    Returns:
        统一格式的错误响应字典
    """
    return {
        "success": False,
        "error_type": error_type,
        "error_message": error_message
    }

def handle_json_error(error: Exception) -> dict:
    """\处理JSON相关错误"""
    return create_error_response("JSON_ERROR", f"JSON处理错误: {str(error)}")

def handle_validation_error(error: Exception) -> dict:
    """\处理验证相关错误"""
    return create_error_response("VALIDATION_ERROR", f"验证失败: {str(error)}")

def handle_generic_error(error: Exception, custom_message: str = None) -> dict:
    """\处理通用错误"""
    message = custom_message or f"处理失败: {str(error)}"
    return create_error_response("GENERIC_ERROR", message)