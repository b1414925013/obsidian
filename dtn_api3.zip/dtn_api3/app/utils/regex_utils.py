import re
import functools


@functools.lru_cache(maxsize=256)
def test_regex(pattern: str, text: str, flags: str = '') -> dict:
    """测试正则表达式匹配
    
    Args:
        pattern: 正则表达式模式
        text: 测试文本
        flags: 正则表达式标志 (i, g, m)
        
    Returns:
        包含匹配结果的字典
    """
    try:
        # 解析标志
        re_flags = 0
        if 'i' in flags:
            re_flags |= re.IGNORECASE
        if 'm' in flags:
            re_flags |= re.MULTILINE
        
        # 编译正则表达式
        regex = re.compile(pattern, re_flags)
        
        # 获取所有匹配项
        matches = list(regex.finditer(text))
        
        # 处理全局匹配
        global_matches = []
        if 'g' in flags or True:  # 默认总是返回所有匹配
            for match in matches:
                # 获取匹配的文本
                match_text = match.group(0)
                
                # 获取捕获组
                groups = []
                for i in range(1, match.lastindex + 1 if match.lastindex is not None else 1):
                    group_text = match.group(i) if i <= match.lastindex else None
                    groups.append({
                        'index': i,
                        'text': group_text,
                        'start': match.start(i) if group_text is not None else -1,
                        'end': match.end(i) if group_text is not None else -1
                    })
                
                global_matches.append({
                    'text': match_text,
                    'start': match.start(),
                    'end': match.end(),
                    'groups': groups
                })
        
        # 生成高亮标记
        highlight_marks = []
        for i, match in enumerate(matches):
            highlight_marks.append({
                'start': match.start(),
                'end': match.end(),
                'match_index': i
            })
        
        # 排序高亮标记（按位置）
        highlight_marks.sort(key=lambda x: x['start'])
        
        return {
            'success': True,
            'pattern': pattern,
            'text': text,
            'flags': flags,
            'matches': global_matches,
            'match_count': len(matches),
            'highlight_marks': highlight_marks
        }
    except re.error as e:
        return {
            'success': False,
            'error': f"正则表达式错误: {str(e)}"
        }
    except Exception as e:
        return {
            'success': False,
            'error': f"处理失败: {str(e)}"
        }


def get_regex_flags_description(flags: str) -> list:
    """获取正则表达式标志的描述
    
    Args:
        flags: 正则表达式标志字符串
        
    Returns:
        标志描述列表
    """
    flag_descriptions = {
        'i': '忽略大小写 (IGNORECASE)',
        'g': '全局匹配 (查找所有匹配项)',
        'm': '多行模式 (MULTILINE)'
    }
    
    descriptions = []
    for flag in flags:
        if flag in flag_descriptions:
            descriptions.append(flag_descriptions[flag])
    
    return descriptions


def escape_regex_special_chars(text: str) -> str:
    """转义正则表达式中的特殊字符
    
    Args:
        text: 输入文本
        
    Returns:
        转义后的文本
    """
    return re.escape(text)


def get_common_regex_examples() -> list:
    """获取常用正则表达式示例
    
    Returns:
        常用正则表达式示例列表
    """
    return [
        {
            'name': '邮箱地址',
            'pattern': r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
            'description': '匹配标准邮箱地址格式'
        },
        {
            'name': '手机号码',
            'pattern': r'1[3-9]\d{9}',
            'description': '匹配中国大陆手机号码'
        },
        {
            'name': 'URL地址',
            'pattern': r'https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)',
            'description': '匹配HTTP或HTTPS URL'
        },
        {
            'name': 'IP地址',
            'pattern': r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$',
            'description': '匹配IPv4地址'
        },
        {
            'name': '日期格式 (YYYY-MM-DD)',
            'pattern': r'\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])',
            'description': '匹配YYYY-MM-DD格式的日期'
        }
    ]