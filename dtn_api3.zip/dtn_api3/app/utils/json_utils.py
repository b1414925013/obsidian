import json
import json5
import functools
from jsonpath_ng import parse


@functools.lru_cache(maxsize=256)
def format_json(json_str: str) -> str:
    """格式化JSON字符串，支持标准JSON和非标准JSON格式（如单引号JSON）"""
    try:
        # 首先尝试使用标准的JSON解析
        data = json.loads(json_str)
        return json.dumps(data, indent=2, ensure_ascii=False)
    except json.JSONDecodeError:
        # 如果标准解析失败，尝试使用json5解析（支持单引号等扩展语法）
        try:
            data = json5.loads(json_str)
            # 将解析后的数据转换回标准JSON格式
            return json.dumps(data, indent=2, ensure_ascii=False)
        except Exception as e:
            raise ValueError(f"无效的JSON格式: {str(e)}")


def extract_jsonpath(json_str: str, jsonpath_expr: str) -> dict:
    """使用JSONPath从JSON中提取数据"""
    
    try:
        data = json.loads(json_str)
        expr = parse(jsonpath_expr)
        matches = [match.value for match in expr.find(data)]
        return {
            "success": True,
            "results": matches,
            "count": len(matches)
        }
    except json.JSONDecodeError:
        return {
            "success": False,
            "error": "无效的JSON格式"
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }