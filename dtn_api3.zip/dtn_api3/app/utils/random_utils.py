import secrets
import string
import uuid
from typing import Dict, List

# 预定义字符集
digits_chars = string.digits
letters_chars = string.ascii_letters
alphanumeric_chars = string.ascii_letters + string.digits
alphanumeric_upper_chars = string.ascii_uppercase + string.digits
alphanumeric_lower_chars = string.ascii_lowercase + string.digits
special_chars = string.ascii_letters + string.digits + "!@#$%^&*()_+-=[]{}|;:,.<>?"


def generate_random_string(characters: str, length: int) -> str:
    """
    生成指定长度和字符集的随机字符串
    使用secrets模块确保随机性安全
    """
    return ''.join(secrets.choice(characters) for _ in range(length))


def generate_random_set(length: int) -> Dict[str, str]:
    """
    生成一组包含7种不同类型的随机字符串
    """
    return {
        "digits": generate_random_string(digits_chars, length),
        "letters": generate_random_string(letters_chars, length),
        "alphanumeric": generate_random_string(alphanumeric_chars, length),
        "alphanumeric_upper": generate_random_string(alphanumeric_upper_chars, length),
        "alphanumeric_lower": generate_random_string(alphanumeric_lower_chars, length),
        "special": generate_random_string(special_chars, length),
        "uuid": str(uuid.uuid4())
    }


def generate_multiple_sets(num: int, length: int) -> List[Dict[str, str]]:
    """
    生成指定数量的随机字符串集合
    """
    # 确保参数有效性
    if not isinstance(num, int) or num <= 0:
        num = 1
    if not isinstance(length, int) or length <= 0:
        length = 8
    
    return [generate_random_set(length) for _ in range(num)]