import io
import qrcode
from PIL import Image


def generate_qrcode(data: str, box_size: int = 10, border: int = 4) -> bytes:
    """生成二维码图片并返回字节数据"""
    try:
        # 创建QRCode对象
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=box_size,
            border=border,
        )
        
        # 添加数据
        qr.add_data(data)
        qr.make(fit=True)
        
        # 创建图像
        img = qr.make_image(fill_color="black", back_color="white")
        
        # 保存到字节流
        buffer = io.BytesIO()
        img.save(buffer, format="PNG")
        buffer.seek(0)
        
        return buffer.read()
    except Exception as e:
        raise ValueError(f"生成二维码失败: {str(e)}")