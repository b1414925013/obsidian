import difflib
import re


def diff_texts(text1: str, text2: str, context_lines: int = 3) -> dict:
    """
    比较两个文本的差异，返回格式化的差异结果
    
    Args:
        text1: 原始文本
        text2: 修改后的文本
        context_lines: 显示的上下文行数
        
    Returns:
        包含差异信息的字典
    """
    try:
        # 将文本按行分割
        lines1 = text1.splitlines(keepends=True)
        lines2 = text2.splitlines(keepends=True)
        
        # 创建差异比较器
        differ = difflib.Differ()
        diff_result = list(differ.compare(lines1, lines2))
        
        # 计算修改统计
        stats = {
            'added': 0,
            'deleted': 0,
            'changed': 0,
            'unchanged': 0
        }
        
        # 处理差异结果
        formatted_diff = []
        for i, line in enumerate(diff_result):
            # 提取差异标记和内容
            tag = line[:2]
            content = line[2:]
            
            # 更新统计信息
            if tag == '  ':
                stats['unchanged'] += 1
            elif tag == '+ ':
                stats['added'] += 1
            elif tag == '- ':
                stats['deleted'] += 1
            elif tag == '? ':
                # 这个标记表示前一行的差异位置，我们不单独计数
                continue
            
            # 添加到格式化结果
            formatted_diff.append({
                'tag': tag,
                'content': content,
                'line_number': i + 1
            })
        
        # 使用上下文差异生成器获取带上下文的差异
        context_diff = difflib.unified_diff(
            lines1, lines2,
            fromfile='原始文本',
            tofile='修改后的文本',
            lineterm='',
            n=context_lines
        )
        
        # 转换为列表以便后续处理
        context_diff_lines = list(context_diff)
        
        # 使用HtmlDiff生成HTML格式的差异
        html_diff = difflib.HtmlDiff().make_file(
            lines1, lines2,
            fromdesc='原始文本',
            todesc='修改后的文本',
            context=True,
            numlines=context_lines
        )
        
        return {
            'success': True,
            'diff_result': formatted_diff,
            'context_diff_lines': context_diff_lines,
            'html_diff': html_diff,
            'stats': stats,
            'line_count1': len(lines1),
            'line_count2': len(lines2)
        }
    except Exception as e:
        return {
            'success': False,
            'error': f'文本差异比较失败: {str(e)}'
        }


def tokenize_text(text: str) -> list:
    """
    将文本分词，用于字符级别的差异比较
    
    Args:
        text: 输入文本
        
    Returns:
        分词后的列表
    """
    # 使用正则表达式将文本分割为单词和非单词字符
    # 保留分隔符
    tokens = re.findall(r'\w+|[^\w\s]|\s+', text)
    return tokens


def diff_tokens(tokens1: list, tokens2: list) -> list:
    """
    比较两个token列表的差异
    
    Args:
        tokens1: 原始token列表
        tokens2: 修改后的token列表
        
    Returns:
        包含差异信息的token列表
    """
    # 创建序列匹配器
    matcher = difflib.SequenceMatcher(None, tokens1, tokens2)
    
    result = []
    
    # 迭代所有匹配块
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == 'equal':
            # 相同的部分
            for token in tokens1[i1:i2]:
                result.append({
                    'type': 'equal',
                    'value': token
                })
        elif tag == 'replace':
            # 替换的部分
            for token in tokens1[i1:i2]:
                result.append({
                    'type': 'deleted',
                    'value': token
                })
            for token in tokens2[j1:j2]:
                result.append({
                    'type': 'added',
                    'value': token
                })
        elif tag == 'delete':
            # 删除的部分
            for token in tokens1[i1:i2]:
                result.append({
                    'type': 'deleted',
                    'value': token
                })
        elif tag == 'insert':
            # 插入的部分
            for token in tokens2[j1:j2]:
                result.append({
                    'type': 'added',
                    'value': token
                })
    
    return result


def format_diff_as_text(diff_result: list) -> str:
    """
    将差异结果格式化为文本
    
    Args:
        diff_result: 差异结果列表
        
    Returns:
        格式化后的文本
    """
    result_lines = []
    for item in diff_result:
        result_lines.append(f"{item['tag']}{item['content']}")
    return ''.join(result_lines)


def get_diff_summary(stats: dict) -> str:
    """
    生成差异摘要
    
    Args:
        stats: 统计信息字典
        
    Returns:
        差异摘要文本
    """
    total_changes = stats['added'] + stats['deleted']
    if total_changes == 0:
        return "两个文本完全相同"
    
    summary = f"共修改 {total_changes} 处: 新增 {stats['added']} 行, 删除 {stats['deleted']} 行"
    return summary