import base64
import re


def is_base64(s: str) -> bool:
    """判断字符串是否为Base64编码"""
    # Base64字符串长度必须是4的倍数
    if len(s) % 4 != 0:
        return False
    
    # 检查Base64字符集
    base64_pattern = r'^[A-Za-z0-9+/]*={0,2}$'
    return bool(re.match(base64_pattern, s))


def encode_to_base64(text: str) -> str:
    """将字符串编码为Base64"""
    try:
        # 使用UTF-8编码
        bytes_data = text.encode('utf-8')
        return base64.b64encode(bytes_data).decode('utf-8')
    except Exception as e:
        raise ValueError(f"编码失败: {str(e)}")


def decode_from_base64(b64_str: str) -> str:
    """将Base64解码为字符串"""
    try:
        bytes_data = base64.b64decode(b64_str)
        return bytes_data.decode('utf-8')
    except Exception as e:
        raise ValueError(f"解码失败: {str(e)}")


def auto_base64_convert(input_str: str) -> dict:
    """自动检测并进行Base64编解码"""
    try:
        if is_base64(input_str):
            # 尝试解码
            decoded = decode_from_base64(input_str)
            return {
                "mode": "decoded",
                "result": decoded
            }
        else:
            # 尝试编码
            encoded = encode_to_base64(input_str)
            return {
                "mode": "encoded",
                "result": encoded
            }
    except Exception as e:
        return {
            "error": str(e)
        }