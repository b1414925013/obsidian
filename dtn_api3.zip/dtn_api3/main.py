from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import uvicorn

# 创建FastAPI应用
app = FastAPI(title="开发者工具箱")

# 配置静态文件目录 - 更新为新的路径
app.mount("/static", StaticFiles(directory="app/static"), name="static")

# 配置模板目录 - 更新为新的路径
templates = Jinja2Templates(directory="app/templates")

# 导入统一的工具路由
from app.routes import router

# 将工具路由注册到主应用
app.include_router(router)

# 工具列表（用于主页九宫格显示）
tools = [
    {
        "id": "json_formatter",
        "name": "JSON格式化工具",
        "description": "格式化JSON字符串，支持语法高亮和一键复制",
        "icon": "📋"
    },
    {
        "id": "jsonpath_checker",
        "name": "JSONPath校验与提取工具",
        "description": "使用JSONPath表达式从JSON数据中提取信息",
        "icon": "🔍"
    },
    {
        "id": "base64_tool",
        "name": "Base64编解码工具",
        "description": "支持字符串与Base64的双向转换，自动识别输入类型",
        "icon": "🔐"
    },
    {
        "id": "timestamp_converter",
        "name": "时间戳转换工具",
        "description": "秒/毫秒时间戳与可读时间的互相转换，支持多时区",
        "icon": "⏱️"
    },
    {
        "id": "regex_tester",
        "name": "正则表达式测试器",
        "description": "测试正则表达式匹配，高亮显示匹配内容",
        "icon": "📝"
    },
    {
        "id": "http_client",
        "name": "HTTP请求模拟器",
        "description": "简易版Postman，支持各种HTTP请求方法",
        "icon": "🌐"
    },
    {
        "id": "qrcode_generator",
        "name": "二维码生成器",
        "description": "生成文本、URL等内容的二维码图片",
        "icon": "📱"
    },
    {
        "id": "naming_converter",
        "name": "变量命名格式转换工具",
        "description": "支持多种命名格式互转，如camelCase、snake_case等",
        "icon": "🔤"
    },
    {
        "id": "text_diff",
        "name": "文本差异对比工具",
        "description": "对比两个文本的差异，高亮显示新增和删除内容",
        "icon": "🔄"
    },
    {
        "id": "sql_formatter",
        "name": "SQL格式化工具",
        "description": "格式化SQL语句，提高可读性",
        "icon": "🗃️"
    }
]

# 主页路由
@app.get("/", response_class=HTMLResponse)
async def read_home(request: Request):
    # 每9个工具一页
    tools_per_page = 9
    total_pages = (len(tools) + tools_per_page - 1) // tools_per_page
    
    # 分组工具
    tool_pages = []
    for i in range(total_pages):
        start = i * tools_per_page
        end = start + tools_per_page
        tool_pages.append(tools[start:end])
    
    return templates.TemplateResponse("index.html", {
        "request": request,
        "tool_pages": tool_pages,
        "total_pages": total_pages
    })

# 工具路由已经移至app/routes/tools.py文件中，通过导入方式集成到主应用
# 运行服务器
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)