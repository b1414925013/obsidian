import requests
import json

# API端点
default_url = "http://localhost:8000/api/get_random_strings"

# 测试不同的请求参数
test_cases = [
    # 测试用例1: 默认参数
    {"params": {}, "description": "使用默认参数（num=1, length=8）"},
    # 测试用例2: 仅指定num
    {"params": {"num": 2}, "description": "仅指定num=2（length=8）"},
    # 测试用例3: 指定num和length
    {"params": {"num": 2, "length": 10}, "description": "指定num=2, length=10"},
    # 测试用例4: 边界情况 - 无效的num
    {"params": {"num": -5}, "description": "无效num（应设为1）"},
    # 测试用例5: 边界情况 - 无效的length
    {"params": {"length": 0}, "description": "无效length（应设为8）"}
]

print("测试随机字符串生成API...\n")

for i, test_case in enumerate(test_cases, 1):
    params = test_case["params"]
    description = test_case["description"]
    
    try:
        # 发送POST请求
        response = requests.post(default_url, json=params)
        response.raise_for_status()  # 如果状态码不是200，抛出异常
        
        # 解析响应
        result = response.json()
        
        # 验证结果
        expected_num = max(1, params.get("num", 1)) if isinstance(params.get("num"), int) else 1
        expected_length = max(8, params.get("length", 8)) if isinstance(params.get("length"), int) else 8
        
        # 打印测试结果
        print(f"测试 {i}: {description}")
        print(f"  请求参数: {params}")
        print(f"  响应状态: {response.status_code} - 成功")
        print(f"  响应结果数量: {len(result)} (预期: {expected_num})")
        
        # 打印第一组结果作为示例
        if result:
            first_set = result[0]
            print(f"  第一组结果示例:")
            for key, value in first_set.items():
                expected_len = 36 if key == "uuid" else expected_length
                print(f"    {key}: {value} (长度: {len(value)}, 预期: {expected_len})")
        
        print()
    except Exception as e:
        print(f"测试 {i}: {description}")
        print(f"  请求参数: {params}")
        print(f"  测试失败: {str(e)}")
        print()

print("测试完成！")