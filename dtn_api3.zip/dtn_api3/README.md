# 开发者工具箱网站

一个功能丰富的开发者在线工具集合，提供多种实用的开发辅助工具，帮助开发者提高工作效率。

## 🚀 项目特点

- **模块化设计**：采用清晰的目录结构和模块化设计，便于维护和扩展
- **多种实用工具**：包含JSON格式化、Base64编解码、时间戳转换等多种常用开发工具
- **响应式UI**：采用现代化的响应式设计，适配不同设备屏幕
- **前后端分离**：基于FastAPI构建的后端API，配合前端模板渲染
- **易于部署**：提供简单的部署指南，支持本地开发和生产环境部署

## 📚 工具列表

| 工具名称 | 功能描述 | 访问路径 |
|---------|---------|---------|
| JSON格式化工具 | 格式化JSON字符串，支持语法高亮和一键复制 | `/json-formatter` |
| JSONPath校验与提取工具 | 使用JSONPath表达式从JSON数据中提取信息 | `/jsonpath-checker` |
| Base64编解码工具 | 支持字符串与Base64的双向转换，自动识别输入类型 | `/base64-tool` |
| 时间戳转换工具 | 秒/毫秒时间戳与可读时间的互相转换，支持多时区 | `/timestamp-converter` |
| 正则表达式测试器 | 测试正则表达式匹配，高亮显示匹配内容 | `/regex-tester` |
| HTTP请求模拟器 | 简易版Postman，支持各种HTTP请求方法 | `/http-client` |
| 二维码生成器 | 生成文本、URL等内容的二维码图片 | `/qrcode-generator` |
| 变量命名格式转换工具 | 支持多种命名格式互转，如camelCase、snake_case等 | `/naming-converter` |
| 文本差异对比工具 | 对比两个文本的差异，高亮显示新增和删除内容 | `/text-diff` |
| SQL格式化工具 | 格式化SQL语句，提高可读性 | `/sql-formatter` |

## 🛠️ 项目结构

```
dtn_api3/
├── app/                       # 主应用目录
│   ├── routes/                # 路由模块
│   │   ├── __pycache__/       # Python编译缓存
│   │   └── tools.py           # 工具路由定义
│   ├── static/                # 静态资源文件
│   │   ├── css/               # CSS样式文件
│   │   ├── js/                # JavaScript文件
│   │   └── favicon.ico        # 网站图标
│   ├── templates/             # HTML模板文件
│   │   ├── base64_tool.html   # Base64工具页面
│   │   ├── http_client.html   # HTTP客户端页面
│   │   ├── index.html         # 主页
│   │   └── ...                # 其他工具页面
│   ├── utils/                 # 工具函数模块
│   │   ├── __pycache__/       # Python编译缓存
│   │   ├── base64_utils.py    # Base64工具函数
│   │   ├── http_utils.py      # HTTP工具函数
│   │   └── ...                # 其他工具函数
│   ├── database/              # 数据库相关模块
│   │   └── __init__.py        # 数据库模块初始化
│   └── models/                # 数据模型模块
│       └── __init__.py        # 数据模型模块初始化
├── main.py                    # 应用程序入口
├── requirements.txt           # 项目依赖列表
└── README.md                  # 项目说明文档
```

## 📋 安装指南

### 1. 确保已安装Python

项目要求Python 3.7或更高版本。可以通过以下命令检查Python版本：

```bash
python --version
```

### 2. 克隆项目代码

```bash
git clone [项目仓库地址]
cd dtn_api3
```

### 3. 安装依赖包

```bash
pip install -r requirements.txt
```

## 🔧 本地开发运行

在项目根目录下执行以下命令启动开发服务器：

```bash
uvicorn main:app --reload
```

服务器启动后，可以通过浏览器访问 http://127.0.0.1:8000 来使用开发者工具箱。

## 🚢 生产环境部署

对于生产环境，可以使用以下命令启动服务器：

```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
```

也可以使用Gunicorn作为WSGI服务器配合Uvicorn工作：

```bash
gunicorn main:app --worker-class uvicorn.workers.UvicornWorker --workers 4 --bind 0.0.0.0:8000
```

## 🔍 API文档

项目提供了自动生成的API文档，可以通过以下路径访问：

- Swagger UI: http://127.0.0.1:8000/docs
- ReDoc: http://127.0.0.1:8000/redoc

## 🤝 贡献指南

欢迎对项目进行贡献！如果您有任何建议或发现了问题，请提交issue或pull request。

## 📝 许可证

[在此添加许可证信息]